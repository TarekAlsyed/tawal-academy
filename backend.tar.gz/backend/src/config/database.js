const { Pool } = require('pg');
require('dotenv').config();

if (!process.env.DATABASE_URL) {
  console.warn('⚠️ تحذير: DATABASE_URL غير محدد في المتغيرات البيئية');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }, // ✅ Required for Supabase pooler and AlwaysData connections without custom CA certs
  // 🕒 إعدادات توفير الطاقة
  max: 10, // تقليل الحد الأقصى للاتصالات لتوفير الموارد
  idleTimeoutMillis: 30000, // إغلاق الاتصالات غير النشطة بعد 30 ثانية (يسمح لـ Neon بالنوم)
  connectionTimeoutMillis: 10000, // وقت انتظار أطول (10 ثواني) لتجنب أخطاء Timeout مع Supabase/Neon
});

pool.on('connect', (client) => {
  // 🕒 Set timezone to Egypt Time (Africa/Cairo) for all connections
  client.query("SET TIME ZONE 'Africa/Cairo'");
  
  // 🚀 Auto-migrate FCM column
  client.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS fcm_token VARCHAR(255)").catch(err => console.error('Migration error:', err));
  
  console.log('✅ متصل بقاعدة البيانات بنجاح (توقيت مصر)');
});

pool.on('error', (err) => {
  console.error('❌ خطأ مفاجئ في قاعدة البيانات:', err);
});

// Test connection (Disabled by default to save Neon CU-hrs on restarts)
const testConnection = async () => {
  if (process.env.NODE_ENV === 'development') {
    if (!process.env.DATABASE_URL) {
      console.error('❌ فشل اختبار الاتصال: DATABASE_URL غير موجود');
      return;
    }
    try {
      const client = await pool.connect();
      console.log('✅ تم اختبار الاتصال بقاعدة البيانات بنجاح');
      client.release();
    } catch (err) {
      console.error('❌ فشل الاتصال بقاعدة البيانات:', err.message);
    }
  }
};

// testConnection(); // تم تعطيله لتوفير الموارد في Neon

module.exports = pool;
